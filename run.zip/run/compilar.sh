#!/bin/bash
g++ -std=c++14 main.cpp -o main.o

#!/bin/bash
./main.o < $1 > $2
